
<?php $__env->startSection('content'); ?>
    <style>
       .icons a {
            margin: 0 30px;
            /* Adjusted margin for more consistent spacing */
            text-decoration: none;
            color: inherit;
            font-size: 1.5em;
            /* Ensures all icons are of uniform size */
        }
    </style>
    <div class="container" style="height: 100%; display: flex; justify-content: center; align-items: center;">
        <table>
            <tr>
                <td style="padding: 10px;">
                    <br>
                    <div class="container" style="height: 100%; display: flex; justify-content: center; align-items: center;">
                        <div style="top: 50%; transform:translate(0, -50%); position: absolute;">
                            <div class="well">
                                <p align="center">
                                    <img src="<?php echo e(asset('storage/' . $Sistem->logo_sistem)); ?>" height="85" />
                                </p>
                                <h4 align="center" style="margin: 15px 0 -10px 0;">
                                    <b><?php echo e($Sistem->nama_sistem); ?><br>STATUS KELULUSAN
                                        SISWA<br><?php echo e($Sistem->nama_sekolah); ?></b>
                                </h4>
                                <hr>
                                <div class="alert alert-info">
                                    <div class="icons" style="text-align: center;">
                                        <a href="https://wa.me/<?php echo e($Sistem->no_hp_sistem); ?>" class="whatsapp-icon">
                                            <i class="bi bi-whatsapp fa-2x" style="margin: 0 10px;"></i> <?php echo e($Sistem->no_hp_sistem); ?>

                                        </a>

                                        <a href="tel:<?php echo e($Sistem->no_hp_sistem); ?>" class="phone-icon" >
                                            <i class="bi bi-telephone-outbound-fill fa-2x" style="margin: 0 10px;"></i><?php echo e($Sistem->no_hp_sistem); ?>

                                        </a>

                                        <a href="mailto:<?php echo e($Sistem->email_sistem); ?>" class="email-icon" >
                                            <i class="bi bi-envelope fa-2x" style="margin: 0 10px;"></i><?php echo e($Sistem->email_sistem); ?>

                                        </a>

                                        <a href="https://maps.google.com/?q=<?php echo e($Sistem->alamat_sistem); ?>" class="location-icon">
                                            <i class="bi bi-geo-alt-fill fa-2x" style="margin: 0 10px;"></i><?php echo e(substr($Sistem->alamat_sistem,0,28).'...'); ?>

                                        </a>
                                    </div>
                                </div>
                            </div>
                            <br>
                        </div>
                    </div>
                </td>
            </tr>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Online.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sik_web\resources\views/Online/contak.blade.php ENDPATH**/ ?>