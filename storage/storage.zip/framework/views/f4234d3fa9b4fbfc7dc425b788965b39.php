
<?php $__env->startSection('content'); ?>
    <style>
        /* General card styles */
        .identitas {
            background-color: #f8f9fa;
            /* Light background */
            border: 1px solid #e9ecef;
            /* Light border */
            border-radius: 5px;
            /* Rounded corners */
            padding: 20px;
            /* Spacing inside the card */
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            /* Subtle shadow */
        }

        /* Table styles */
        table {
            width: 100%;
            /* Full width */
            border-collapse: collapse;
            /* Remove gaps between table cells */
            margin-bottom: 20px;
            /* Spacing below the table */
        }

        th,
        td {
            padding: 10px 10px;
            /* Spacing inside table cells */
            text-align: left;
            /* Left align text */
        }

        th.label {
            width: 250px;
            font-weight: bold;
            /* Bold labels */
            color: #343a40;
            /* Dark text color */
        }

        td.colon {
            width: 10px;
            /* Narrow column for colons */
        }

        td.isi_label {
            color: #6c757d;
            /* Muted text color */
        }

        /* Image styles */
        .text-center {
            text-align: center;
            /* Center-align image */
        }

        .img-responsive {
            max-width: 100%;
            /* Make image responsive */
            height: auto;
            /* Maintain aspect ratio */
            border-radius: 50%;
            /* Circular image */
            border: 2px solid #dee2e6;
            /* Light border around image */
            margin-top: 20px;
            /* Spacing above the image */
        }

        /* Alert styles */
        .alert {
            margin-top: 20px;
            /* Spacing above the alert */
        }

        .alert-icon {
            margin-right: 10px;
            /* Spacing to the right of the icon */
        }

        .alert-message {
            margin-left: 35px;
            /* Spacing to the left of the icon */
        }

        /* Button close styles */
        .btn-close {
            position: absolute;
            top: 10px;
            /* Positioning within alert */
            right: 10px;
            /* Positioning within alert */
            background: transparent;
            /* Transparent background */
            border: none;
            /* No border */
            font-size: 1.25rem;
            /* Larger size */
            cursor: pointer;
            /* Pointer cursor */
        }
    </style>
    <script src="<?php echo e(asset('assets/admin/js/settings.js')); ?>"></script>
    <link href=" <?php echo e(asset('assets/admin/css/modern.css')); ?>" type="text/css" rel="stylesheet">
    <main class="content">
        <div class="container-fluid">

            <div class="header">
                <h1 class="header-title">
                    Verifikasi Data Kelulusan Siswa/i
                </h1>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="tab">
                            <ul class="nav nav-tabs" role="tablist">
                                <li class="nav-item"><a class="nav-link active" href="#tab-1" data-bs-toggle="tab"
                                        role="tab">Verifikasi</a></li>
                                <li class="nav-item"><a class="nav-link" href="#tab-2" data-bs-toggle="tab"
                                        role="tab">Data Verifikasi</a></li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane active" id="tab-1" role="tabpanel">
                                    <div class="card-header">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="col-md-6">
                                                    <div class="input-group">
                                                        <input type="text" class="form-control"
                                                            name="kode_veryfikasi_siswa" id="kode_veryfikasi_siswa"
                                                            placeholder="Kode Verifikasi"
                                                            onkeypress="return hanyaAngka(event)">
                                                        <button class="btn btn-success" name="button_veryfikasi"
                                                            id="button_veryfikasi" type="submit">Cek Data</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="card">
                                            <div class="card-body identitas">
                                                <div class="row">
                                                    <div class="col-md-8">
                                                        <table>
                                                            <tr>
                                                                <th class="label">Nama</th>
                                                                <td class="colon">:</td>
                                                                <td class="isi_label" id="nama_siswa">-</td>
                                                            </tr>
                                                            <tr>
                                                                <th class="label">Nomor Induk Nasional (NISN)</th>
                                                                <td class="colon">:</td>
                                                                <td class="isi_label" id="nisn_siswa">-</td>
                                                            </tr>
                                                            <tr>
                                                                <th class="label">Nomor Ujian</th>
                                                                <td class="colon">:</td>
                                                                <td class="isi_label" id="nomor_ujian_siswa">-</td>
                                                            </tr>
                                                            <tr>
                                                                <th class="label">Tempat/Tanggal Lahir</th>
                                                                <td class="colon">:</td>
                                                                <td class="isi_label" id="tggl_lahir_siswa">-</td>
                                                            </tr>
                                                            <tr>
                                                                <th class="label">Jenis Kelamin</th>
                                                                <td class="colon">:</td>
                                                                <td class="isi_label" id="jk_siswa">-</td>
                                                            </tr>
                                                            <tr>
                                                                <th class="label">Orang Tua/Wali</th>
                                                                <td class="colon">:</td>
                                                                <td class="isi_label" id="orang_tua_siswa">-</td>
                                                            </tr>
                                                            <tr>
                                                                <th class="label">Nomor HP</th>
                                                                <td class="colon">:</td>
                                                                <td class="isi_label" id="no_hp_siswa">-</td>
                                                            </tr>
                                                            <tr>
                                                                <th class="label">Email</th>
                                                                <td class="colon">:</td>
                                                                <td class="isi_label" id="email_siswa">-</td>
                                                            </tr>
                                                            <tr>
                                                                <th class="label">Alamat</th>
                                                                <td class="colon">:</td>
                                                                <td class="isi_label" id="alamat_siswa">-</td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="text-center">
                                                            <img alt="Chris Wood"
                                                                src="<?php echo e(asset('assets/admin/img/avatars/avatar.jpg')); ?>"
                                                                class="mt-2" width="200" height="250" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <button type="submit" id="submitBtn"
                                                    class="btn btn-primary">Veryfikasi</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane" id="tab-2" role="tabpanel">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-12">
                                                <table id="datatables-ajax" class="table table-striped"
                                                    style="width:100%">
                                                    <thead>
                                                        <tr>
                                                            <th>No.</th>
                                                            <th>Name</th>
                                                            <th>NISN</th>
                                                            <th>Nomor Ujian</th>
                                                            <th>Kode Verifikasi</th>
                                                            <th>Status</th>
                                                            <th>Tanggal Verifikasi</th>
                                                        </tr>
                                                    </thead>
                                                    <tfoot>
                                                        <tr>
                                                            <th>No.</th>
                                                            <th>Name</th>
                                                            <th>NISN</th>
                                                            <th>Nomor Ujian</th>
                                                            <th>Kode Verifikasi</th>
                                                            <th>Status</th>
                                                            <th>Tanggal Verifikasi</th>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <!-- Your other content -->
    <script src="<?php echo e(asset('assets/admin/js/app.js')); ?>"></script>
    <script>
        
        $(document).ready(function() {

            // menampilkan data
            DataVerifikasi();

            function DataVerifikasi() {
                $('#datatables-ajax').DataTable({
                    processing: true,
                    serverSide: false,
                    ajax: '<?php echo e(url('siswa/DataTabelVeryfikasi')); ?>',
                    columns: [{
                            data: null,
                            name: 'nomor',
                            render: function(data, type, row, meta) {
                                return meta.row + 1;
                            }
                        },
                        {
                            data: 'nama_siswa',
                            name: 'nama_siswa',
                            render: function(data, type, row) {
                                return data.toUpperCase();
                            }
                        },
                        {
                            data: 'nisn_siswa',
                            name: 'nisn_siswa'
                        },
                        {
                            data: 'nomor_ujian_siswa',
                            name: 'nomor_ujian_siswa'
                        },
                        {
                            data: 'kode_verifikasi_siswa',
                            name: 'kode_verifikasi_siswa'
                        },
                        {
                            data: 'veryfikasi_status',
                            name: 'veryfikasi_status',
                            render: function(data, type, row) {
                                return data === 1 ?
                                    '<span class="badge bg-success">Terverifikasi</span>' :
                                    '<span class="badge bg-success">Tidak Terverifikasi</span>';
                            }
                        },
                        {
                            data: 'tanggal_verifikasi',
                            name: 'tanggal_verifikasi'
                        }
                    ]
                });
            }


            var nisn_siswa_kode = '';
            $('#submitBtn').hide();
            // Event listener for the verification button click
            $('#button_veryfikasi').click(function() {
                // Get the verification code entered by the user
                var kodeVeryfikasi = $('#kode_veryfikasi_siswa').val();

                // Get the CSRF token value from the meta tag
                var csrfToken = $('meta[name="csrf-token"]').attr('content');

                // Send an AJAX request to the server
                $.ajax({
                    url: '<?php echo e(url('siswa/ProsesCekData')); ?>', // Laravel base URL with route
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        kode_verifikasi_siswa: kodeVeryfikasi, // Send verification code to the server
                        _token: csrfToken // Include the CSRF token
                    },
                    success: function(response) {
                        function capitalizeFirstLetter(string) {
                            return string.charAt(0).toUpperCase() + string.slice(1);
                        }
                        // Handle the response from the server
                        if (response.success) {
                            Swal.fire({
                                title: 'Berhasil!',
                                text: response.message,
                                icon: 'success',
                                confirmButtonText: 'OK'
                            });

                            var ttg_lahir = response.data.tempat_lahir + ' / ' + response.data
                                .tempat_lahir;
                            var jk = '';
                            if (response.data.jenis_kelamin_siswa == 'L') {
                                jk = "Laki - Laki";
                            } else {
                                jk = "Perempuan";
                            }
                            $('#nama_siswa').text(capitalizeFirstLetter(response.data
                                .nama_siswa));
                            $('#nisn_siswa').text(response.data.nisn);
                            $('#nomor_ujian_siswa').text(response.data.nomor_ujian_siswa);
                            $('#tggl_lahir_siswa').text(response.data.nama_siswa);
                            $('#jk_siswa').text(jk);
                            $('#orang_tua_siswa').text(capitalizeFirstLetter(response.data
                                .orang_tua));
                            $('#no_hp_siswa').text(response.data.no_hp_siswa);
                            $('#email_siswa').text(response.data.email_siswa);
                            $('#alamat_siswa').text(capitalizeFirstLetter(response.data
                                .alamat_siswa));
                            nisn_siswa_kode = response.data.nisn;
                            $('#submitBtn').show();
                        } else {
                            Swal.fire({
                                title: 'Error!',
                                text: response.message,
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        // Handle AJAX errors
                        console.error(xhr.responseText);
                    }
                });
            });
            // prosses veryfikasion
            $('#submitBtn').click(function() {
                // Get the verification code entered by the user
                var kodeVeryfikasi = $('#kode_veryfikasi_siswa').val();

                // Get the CSRF token value from the meta tag
                var csrfToken = $('meta[name="csrf-token"]').attr('content');

                // Send an AJAX request to the server
                $.ajax({
                    url: '<?php echo e(url('siswa/ProsesVeryfikasi/')); ?>/' +
                        kodeVeryfikasi, // Laravel base URL with route
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        nisn_siswa_kode: nisn_siswa_kode, // Send verification code to the server
                        _token: csrfToken // Include the CSRF token
                    },
                    success: function(response) {
                        function capitalizeFirstLetter(string) {
                            return string.charAt(0).toUpperCase() + string.slice(1);
                        }
                        // Handle the response from the server
                        if (response.success) {
                            Swal.fire({
                                title: 'Berhasil!',
                                text: response.message,
                                icon: 'success',
                                confirmButtonText: 'OK'
                            });
                            $('#submitBtn').hide();
                            DataVerifikasi();
                        } else {
                            Swal.fire({
                                title: 'Error!',
                                text: response.message,
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        // Handle AJAX errors
                        console.error(xhr.responseText);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sik_web\resources\views/Admin/siswa/veryfikasi_siswa.blade.php ENDPATH**/ ?>