<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css"
        integrity="sha384-QYIZto+st3yW+o8+5OHfT6S482Zsvz2WfOzpFSXMF9zqeLcFV0/wlZpMtyFcZALm" crossorigin="anonymous">
</head>
<style type="text/css">
    body {
        background-color: #88BDBF;
        margin: 0px;
    }
</style>

<body>
    <table border="0" width="50%"
        style="margin:auto;padding:30px;background-color: #F3F3F3;border:1px solid #153d77;">
        <tr>
            <td>
                <table border="0" width="100%">
                    <tr>
                        <td style="text-align: center;">
                            <h3><?php echo e($data['Sistem']); ?></h3>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td>
                <table border="0" cellpadding="0" cellspacing="0"
                    style="text-align:center;width:100%;background-color: #fff;">
                    <tr>
                        <td style="background-color:#153d77;height:100px;font-size:50px;color:#153d77;"><img
                                src="<?php echo e($data['Logo']); ?>"
                                alt="" style= "width: 100px;height: 100px;border-radius: 50%;"></td>
                    </tr>
                    <tr>
                        <td style="font-size:12px; padding-top:25px; padding-left: 10px; text-align: left">
                            <span ><?php echo e($data['message']); ?><br>
                                Tanggal Daftar: <?php echo e($data['tanggal']); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p style="padding:0px 100px;">
                                Klik dibawah ini.
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <a href="#"
                                style="margin:10px 0px 30px 0px;border-radius:4px;padding:10px 20px;border: 0;color:#fff;background-color:#153d77; "
                                target="_blank" style="text-decoration: none;">CEK DATA</a>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td>
                <table border="0" width="100%" style="border-radius: 5px;text-align: center;">
                    <tr>
                        <td>
                            <div style="margin-top: 20px;">
                                <span style="font-size:12px;"><?php echo e($data['Sekolah']); ?> <br> <?php echo e($data['Alamat']); ?></span><br><?php echo e($data['Sistem']); ?>

                                <span style="font-size:12px;">Copyright &copy; <?php echo e(date('Y', strtotime($data['Tanggal']))); ?></span>
                            </div>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>

</html>
<?php /**PATH C:\laragon\www\sik_web\resources\views/Admin/pengguna/emailDaftar.blade.php ENDPATH**/ ?>