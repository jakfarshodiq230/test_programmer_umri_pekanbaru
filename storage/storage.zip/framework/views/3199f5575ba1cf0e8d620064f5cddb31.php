
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid">

            <div class="header">
                <h1 class="header-title">
                    Data Periode Kelulusan Siswa/i
                </h1>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-actions float-end">
                                <div>
                                    <button class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#centeredModalPrimary" title="tambah data siswa"><i
                                            class="fas fa-add"></i></button>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table id="datatables-buttons" class="table table-striped" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>ID</th>
                                        <th>Judul</th>
                                        <th>Tahun</th>
                                        <th>Tanggal & Jam</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $nomor = 0; ?>
                                    <?php $__currentLoopData = $Periode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $nomor++; ?>
                                        <tr>
                                            <td><?= $nomor ?></td>
                                            <td><?= $item->id_periode ?></td>
                                            <td><?= strtoupper($item->judul_periode) ?></td>
                                            <td><?= $item->tahun_periode ?></td>
                                            <td><?= date('d F Y, h:i:s ', strtotime($item->tanggal_jam_periode)) ?></td>
                                            <td>
                                                <a href="<?php echo e(url('periode/hapus/' . $item->id_periode)); ?>" class="btn btn-danger"
                                                    title="hapus data siswa/i perpriode kelulusan" data-bs-toggle="tooltip" data-bs-placement="top"
                                                    data-confirm-delete="true"><i class="fas fa-trash"></i></a>
                                                <button class="btn btn-warning" data-bs-toggle="modal"
                                                    data-bs-target="#editPriode<?= $item->id_periode ?>"
                                                    title="tambah data siswa"><i class="fas fa-pencil"></i></button>

                                                
                                                <div class="modal fade" id="editPriode<?= $item->id_periode ?>"
                                                    tabindex="-1" role="dialog" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
                                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                                        <div class="modal-content">
                                                            <form method="POST" action="<?php echo e(url('periode/rubah/'.$item->id_periode)); ?>" enctype="multipart/form-data">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">EDIT PERIODE KELULUSAN</h5>
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal" aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body m-3">
                                                                    <div class="row">
                                                                        <div class="col-12 col-lg-12">
                                                                            <div class="mb-3">
                                                                                <label>Judul</label>
                                                                                <textarea name="judul_periode" class="form-control" placeholder="judul pengumuman" required><?= $item->judul_periode ?></textarea>
                                                                            </div>
                                                                            <div class="mb-3">
                                                                                <label class="form-label">Tanggal &
                                                                                    Jam</label>
                                                                                <div class="input-group date"
                                                                                    name="tanggal_pengumuman"
                                                                                    id="datetimepicker-view-mode2"
                                                                                    data-target-input="nearest">
                                                                                    <input type="text" name="tanggal_periode"
                                                                                        class="form-control datetimepicker-input"
                                                                                        data-target="#datetimepicker-view-mode2"
                                                                                        value="<?= $item->tanggal_jam_periode ?>" />
                                                                                    <div class="input-group-text"
                                                                                        data-target="#datetimepicker-view-mode2"
                                                                                        data-toggle="datetimepicker"><i
                                                                                            class="fas fa-calendar"></i>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="mb-3">
                                                                                <label>Tahun</label>
                                                                                <input type="text" name="tahun_periode" class="form-control"
                                                                                    placeholder="tahun periode" value="<?= $item->tahun_periode ?>" required>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-bs-dismiss="modal">Batal</button>
                                                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>

                        </div>

                        
                        <div class="modal fade" id="centeredModalPrimary" tabindex="-1" role="dialog" aria-hidden="true"
                            data-bs-keyboard="false" data-bs-backdrop="static">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <form  method="POST" action="<?php echo e(url('periode/simpan')); ?>"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-header">
                                            <h5 class="modal-title">TAMBAH PERIODE KELULUSAN</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body m-3">
                                            <div class="row">
                                                <div class="col-12 col-lg-12">
                                                    <div class="mb-3">
                                                        <label>Judul</label>
                                                        <textarea name="judul_periode" class="form-control" placeholder="judul pengumuman" required></textarea>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Tanggal & Jam</label>
                                                        <div class="input-group date" id="datetimepicker-view-mode"
                                                            data-target-input="nearest">
                                                            <input type="text"
                                                                class="form-control datetimepicker-input"
                                                                data-target="#datetimepicker-view-mode"
                                                                name="tanggal_periode" required />
                                                            <div class="input-group-text"
                                                                data-target="#datetimepicker-view-mode"
                                                                data-toggle="datetimepicker"><i
                                                                    class="fas fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label>Tahun</label>
                                                        <input type="text" name="tahun_periode" class="form-control"
                                                            placeholder="tahun periode" required>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Batal</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sik_web\resources\views/Admin/priode/data_priode.blade.php ENDPATH**/ ?>