
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid">

            <div class="header">
                <h1 class="header-title">
                    Data Siswa/i Kelulusan
                </h1>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-actions float-end">
                                <div>
                                    <button class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#centeredModalPrimary" title="tambah data siswa"><i
                                            class="fas fa-user-plus"></i></button>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table id="datatables-buttons" class="table table-striped" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Judul</th>
                                        <th>Tahun</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $nomor = 0; ?>
                                    <?php $__currentLoopData = $Periode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $nomor++; ?>
                                        <tr>
                                            <td><?= $nomor ?></td>
                                            <td><?= strtoupper($item->judul_periode) ?></td>
                                            <td><?= $item->tahun_periode ?></td>
                                            <td>
                                                <a href="<?php echo e(url('siswa/hapusAll/' . $item->id_periode)); ?>"
                                                    class="btn btn-danger" data-confirm-delete="true"
                                                    data-bs-toggle="tooltip" data-bs-placement="top" title="hapus data siswa/i perpriode kelulusan"><i
                                                        class="fas fa-trash"></i></a>
                                                <a href="<?php echo e(url('siswa/detail/' . $item->id_periode)); ?>"
                                                    data-bs-toggle="tooltip" data-bs-placement="top" class="btn btn-success" title="lihat data siswa/i perpriode kelulusan"><i
                                                        class="fas fa-user-check"></i></a>
                                                <a href="<?php echo e(url('siswa/pesan_email/' . $item->id_periode)); ?>"
                                                    data-bs-toggle="tooltip" data-bs-placement="top" class="btn btn-secondary" title="kirim pengumuman kelulusan semua siswa/i"><i
                                                        class="fas fa-envelope"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>

                        
                        <div class="modal fade" id="centeredModalPrimary" tabindex="-1" role="dialog" aria-hidden="true"
                            data-bs-keyboard="false" data-bs-backdrop="static">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <form method="POST" action="<?php echo e(url('siswa/simpan')); ?>" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-header">
                                            <h5 class="modal-title">TAMBAH DATA SISWA</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body m-3">
                                            <div class="row">
                                                <div class="col-12 col-lg-12">
                                                    <div class="mb-3">
                                                        <label>Priode Kelulusan</label>
                                                        <select class="form-control select2" name="priode_lulus"
                                                            data-bs-toggle="select2" required>
                                                            <?php $__currentLoopData = $Periode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?= $item->id_periode ?>">
                                                                    <?= $item->judul_periode.' - '.$item->tahun_periode ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-12 col-lg-6">
                                                    <div class="mb-3">
                                                        <label>Nomor Surat</label>
                                                        <input type="text" name="nomor_surat" class="form-control"
                                                            placeholder="Nomor Surat" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label>Nama</label>
                                                        <input type="text" name="nama_siswa" class="form-control"
                                                            placeholder="Nama siswa/i" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label>Tempat Lahir</label>
                                                        <input type="text" name="tempat_lahir" class="form-control"
                                                            placeholder="Tempat Lahir Siswa/i" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label>Tanggal Lahir</label>
                                                        <input type="date" name="tanggal_lahir_siswa"
                                                            class="form-control " required />
                                                    </div>
                                                    <div class="mb-3">
                                                        <label>Nomor Ujian</label>
                                                        <input type="text" name="nomor_ujian_siswa" class="form-control"
                                                            placeholder="Nomor ujian siswa/i" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label>No HP</label>
                                                        <input type="text" name="no_hp_siswa" class="form-control" onkeypress="return hanyaAngka(event)"
                                                            placeholder="No HP siswa/i" required>
                                                    </div>

                                                </div>
                                                <div class="col-12 col-lg-6">
                                                    <div class="mb-3">
                                                        <label>Tanggal Surat</label>
                                                        <input type="text" name="tanggal_surat" class="form-control"
                                                            placeholder="Pekanbaru, 21 Juli 2024" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label>NISN</label>
                                                        <input type="text" name="nisn_siswa" class="form-control" onkeypress="return hanyaAngka(event)"
                                                            placeholder="NISN siswa/i" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label>Jenis Kelamin</label>
                                                        <select class="form-control mb-3" name="jenis_kelmain_siswa"
                                                            required>
                                                            <option selected>PILIH</option>
                                                            <option value="L">LAKI-LAKI</option>
                                                            <option value="P">PEREMPUAN</option>
                                                        </select>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label>Keterangan</label>
                                                        <select class="form-control mb-3" name="keterangan_siswa"
                                                            required>
                                                            <option selected>PILIH</option>
                                                            <option value="1">LULUS</option>
                                                            <option value="0">TIDAK LULUS</option>
                                                        </select>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label>Email</label>
                                                        <input type="email" name="email_siswa" class="form-control"
                                                            placeholder="Email siswa/i" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label>Orang Tua/Wali</label>
                                                        <input type="text" name="orang_tua" class="form-control"
                                                            placeholder="Nama orang tua / wali" required>
                                                    </div>
                                                </div>
                                                <div class="col-12 col-lg-12">
                                                    <div class="mb-3">
                                                        <label>Kepala Sekolah</label>
                                                        <input type="text" name="tandat_angan_surat"
                                                            class="form-control" placeholder="Nama kepala sekolah"
                                                            required>
                                                    </div>
                                                    <label>Alamat</label>
                                                    <textarea name="alamat_siswa" class="form-control" placeholder="Alamat siswa/i" required></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Batal</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sik_web\resources\views/Admin/siswa/data_siswa.blade.php ENDPATH**/ ?>