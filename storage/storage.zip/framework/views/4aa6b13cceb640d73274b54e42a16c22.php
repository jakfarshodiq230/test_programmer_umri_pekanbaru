
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid">

            <div class="header">
                <h1 class="header-title">
                    Format Surat Kelulusan
                </h1>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-actions float-end">
                                <div>
                                    <a href="<?php echo e(url('stl/sinkronisasi/'. $Surat->id_surat)); ?>" class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#centeredModalPrimary" title="Sinkronisasi data format surat" data-bs-toggle="tooltip" data-bs-placement="top"><i
                                            class="fas fa-refresh" style="color: white;"></i></a>
                                </div>
                            </div>
                            <h5 class="card-title mb-0">Info STL </h5>
                        </div>
                        <div class="card-body">
                            <div class="col-12 col-lg-12">
                                <div class="tab">
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li class="nav-item"><a class="nav-link active" href="#tab-1" data-bs-toggle="tab"
                                                role="tab">Kop Surat</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#tab-2" data-bs-toggle="tab"
                                                role="tab">Isi Surat</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#tab-3" data-bs-toggle="tab"
                                                role="tab">Lihat Surat</a></li>
                                    </ul>

                                    <div class="tab-content">
                                        <div class="tab-pane active" id="tab-1" role="tabpanel">
                                            <form method="POST" action="<?php echo e(url('stl/update/kop/' . $Surat->id_surat)); ?>"
                                                enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="col-md-12">
                                                    <div class="mb-3">
                                                        <label for="inputUsername">Kalimat 1</label>
                                                        <input class="form-control" name="kalimat_kop_1" id="kalimat_kop_1"
                                                            value="<?php echo e($Surat->kalimat_kop_1); ?>"></input>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="inputUsername">Kalimat 2</label>
                                                        <input class="form-control" name="kalimat_kop_2" id="kalimat_kop_2"
                                                            value="<?php echo e($Sistem->nama_sekolah); ?>" readonly></input>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="inputUsername">Akreditasi</label>
                                                        <input class="form-control" name="akreditasi_kop"
                                                            id="akreditasi_kop"
                                                            value="<?php echo e($Surat->akreditasi_kop); ?>"></input>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="inputUsername">Link</label>
                                                        <input class="form-control" name="link_kop" id="link_kop"
                                                            value="<?php echo e($Surat->link_kop); ?>"></input>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="inputUsername">ALamat</label>
                                                        <input class="form-control" name="alamat_kop" id="alamat_kop"
                                                            value="<?php echo e($Surat->alamat_kop); ?>"></input>
                                                    </div>
                                                </div>
                                                <button type="button" onclick="toggleInputsKop()"
                                                    class="btn btn-warning">Edit
                                                    Data</button>
                                                <button type="submit" id="submitBtnKop"
                                                    class="btn btn-primary">Update</button>
                                            </form>
                                            <script>
                                                document.getElementById("submitBtnKop").disabled = true;

                                                function toggleInputsKop() {
                                                    document.getElementById("submitBtnKop").disabled = false;
                                                }
                                            </script>
                                        </div>
                                        <div class="tab-pane" id="tab-2" role="tabpanel">
                                            <form method="POST" action="<?php echo e(url('stl/update/' . $Surat->id_surat)); ?>"
                                                enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="row">
                                                    <div class="col-md-8">
                                                        <div class="mb-3">
                                                            <label for="inputUsername">Judul Surat</label>
                                                            <input class="form-control" name="judul_surat" id="judul_surat"
                                                                value="<?php echo e($Surat->judul_surat); ?>"></input>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="inputUsername">Kalimat Pembuka</label>
                                                            <textarea class="form-control" name="kalimat_pembuka" id="kalimat_pembuka" cols="30" rows="5"><?php echo e($Surat->kalimat_pembuka); ?></textarea>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="inputUsername">Kalimat isi</label>
                                                            <textarea class="form-control" name="kalimat_isi" id="kalimat_isi" cols="30" rows="5"><?php echo e($Surat->kalimat_isi); ?></textarea>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="inputUsername">Kalimat Penutup</label>
                                                            <textarea class="form-control" name="kalimat_penutup" id="kalimat_penutup" cols="30" rows="5"><?php echo e($Surat->kalimat_penutup); ?></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="text-center">
                                                            <div class="mt-2">
                                                                <span>Tanda Tangan + Stampel</span>
                                                            </div>
                                                            <?php if($Surat->tanda_tangan == null): ?>
                                                                <img alt="Chris Wood"
                                                                    src="<?php echo e(asset('assets/admin/img/avatars/avatar.jpg')); ?>"
                                                                    class="rounded-circle img-responsive mt-2"
                                                                    width="220" height="128" />
                                                            <?php else: ?>
                                                                <img alt="Chris Wood"
                                                                    src="<?php echo e(asset('storage/' . $Surat->tanda_tangan)); ?>"
                                                                    class="img-responsive mt-2" width="220"
                                                                    height="128" />
                                                            <?php endif; ?>

                                                            <div class="mt-2">
                                                                <span class="btn btn-primary"><input type="file"
                                                                        name="tanda_tangan" id="tanda_tangan"></span>
                                                            </div>
                                                            <small>Format jpg dan png</small>
                                                        </div>

                                                        

                                                        <?php if($errors->any()): ?>
                                                            <div class="alert alert-danger alert-outline-coloured alert-dismissible p-2"
                                                                role="alert">
                                                                <div class="alert-icon">
                                                                    <i class="far fa-fw fa-bell"></i>
                                                                </div>
                                                                <div class="alert-message">
                                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <li class="text-danger"><?php echo e($error); ?></li>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>
                                                                <button type="button" class="btn-close "
                                                                    data-bs-dismiss="alert" aria-label="Close"></button>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <button type="button" onclick="toggleInputs()"
                                                    class="btn btn-warning">Edit
                                                    Data</button>
                                                <button type="submit" id="submitBtn"
                                                    class="btn btn-primary">Update</button>

                                                <script>
                                                    document.getElementById("submitBtn").disabled = true;
                                                    var inputs = ['kalimat_pembuka', 'kalimat_isi', 'kalimat_penutup', 'judul_surat'];
                                                    inputs.forEach(function(id) {
                                                        var inputField = document.getElementById(id);
                                                        inputField.readOnly = !inputField.readOnly;
                                                    });

                                                    function toggleInputs() {
                                                        document.getElementById("submitBtn").disabled = false;
                                                        var inputs = ['kalimat_pembuka', 'kalimat_isi', 'kalimat_penutup', 'judul_surat'];
                                                        inputs.forEach(function(id) {
                                                            var inputField = document.getElementById(id);
                                                            inputField.readOnly = !inputField.readOnly;
                                                        });
                                                    }
                                                </script>
                                            </form>
                                        </div>
                                        <div class="tab-pane" id="tab-3" role="tabpanel">
                                            <div class="col-md-12">
                                                <iframe src="<?php echo e(asset('storage/surat/surat_tanda_kelulusan.pdf')); ?>"
                                                    width="100%" height="600px">
                                                    Your browser does not support iframes.
                                                </iframe>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sik_web\resources\views/Admin/surat/data_surat.blade.php ENDPATH**/ ?>