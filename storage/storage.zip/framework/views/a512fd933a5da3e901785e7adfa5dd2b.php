<!DOCTYPE html>
<html>

<head>
    <style>
        body {
            font-family: helvetica;
        }

        .kop_surat {
            text-align: center;
            font-size: 14pt;
            text-decoration: underline;
            font-weight: bold;
            text-transform: uppercase;
        }

        .kalimat_isi,
        .kalimat_pembuka,
        .kalimat_penutup {
            text-align: justify;
            font-size: 12pt;
        }

        .kelulusan {
            text-align: center;
            font-size: 16pt;
            font-weight: bold;
        }

        .nomor {
            margin-top: -1000px !important;
            text-align: center !important;
            font-size: 13pt;
            font-weight: bold;
        }

        .label {
            width: 35%;
            font-size: 12pt;
        }

        .colon {
            width: 5%;
            text-align: center;
        }

        .isi_label {
            width: 65%;
            font-size: 12pt;
        }


        .tandatangan {
            font-size: 12pt;
            text-align: right;
        }

        .namakepsek {
            font-size: 12pt;
            text-align: right;
        }

        .catatan {
            text-align: left;
            font-size: 8pt;
            font-style: italic;
            color: brown;
        }
    </style>
</head>

<body>
    <p style="text-align: center;"><span class="kop_surat"> <?php echo e($surat->judul_surat); ?> </span>
        <br>
        <span class="nomor">NOMOR : -</span>
    </p>
    <br><br>
    <span class="kalimat_pembuka"><?php echo e($surat->kalimat_pembuka); ?></span>
    <br><br>
    
    <table>
        <tr>
            <th class="label">Nama</th>
            <td class="colon">:</td>
            <td class="isi_label">-</td>
        </tr>
        <tr>
            <th class="label">Nomor Induk Nasional (NISN)</th>
            <td class="colon">:</td>
            <td class="isi_label">-</td>
        </tr>
        <tr>
            <th class="label">Nomor Ujian</th>
            <td class="colon">:</td>
            <td class="isi_label">-</td>
        </tr>
        <tr>
            <th class="label">Tempat/Tanggal Lahir</th>
            <td class="colon">:</td>
            <td class="isi_label">-</td>
        </tr>
        <tr>
            <th class="label">Jenis Kelamin</th>
            <td class="colon">:</td>
            <td class="isi_label">-</td>
        </tr>
        <tr>
            <th class="label">Orang Tua/Wali</th>
            <td class="colon">:</td>
            <td class="isi_label">-</td>
        </tr>
        <tr>
            <th class="label">Nomor HP</th>
            <td class="colon">:</td>
            <td class="isi_label">-</td>
        </tr>
        <tr>
            <th class="label">Email</th>
            <td class="colon">:</td>
            <td class="isi_label">-</td>
        </tr>
        <tr>
            <th class="label">Alamat</th>
            <td class="colon">:</td>
            <td class="isi_label">-</td>
        </tr>
    </table>
    
    <br><br>
    <span class="kalimat_isi"><?php echo e($surat->kalimat_isi); ?></span>
    <h1 class="kelulusan">-</h1>
    <p class="kalimat_penutup"><?php echo e($surat->kalimat_penutup); ?></p>

</body>

</html>
<?php /**PATH C:\laragon\www\sik_web\resources\views/Admin/surat/cetak_pdf.blade.php ENDPATH**/ ?>