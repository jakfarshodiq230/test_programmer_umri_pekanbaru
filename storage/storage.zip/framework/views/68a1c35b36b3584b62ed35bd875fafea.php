
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid">
            <div class="header">
                <h1 class="header-title">
                    Data <?= ucwords($Periode->judul_periode) . ' Tahun ' . $Periode->tahun_periode ?>
                </h1>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger alert-outline-coloured alert-dismissible p-2" role="alert">
                                <div class="alert-icon">
                                    <i class="far fa-fw fa-bell"></i>
                                </div>
                                <div class="alert-message">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="text-danger"><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <button type="button" class="btn-close " data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <div class="card-header">
                            <div class="card-actions float-end">
                                <a href="<?php echo e(url('siswa/export/' . $Periode->id_periode)); ?>" class="btn btn-warning"
                                    title="Export data siswa/i perpriode kelulusan" data-bs-toggle="tooltip" data-bs-placement="top"><i class="fas fa-download" style="color: white;"></i></a>
                                <button class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#centeredModalPrimary" title="Upload data excel siswa siswa/i "><i
                                        class="fas fa-upload"></i></button>
                            </div>
                        </div>
                        <div class="card-body">
                            <table id="datatables-buttons" class="table table-striped" style="width:100%">
                                <thead>
                                    <tr>
                                        
                                        <th></th>
                                        <th></th>
                                        <th>Nama</th>
                                        <th>NISN</th>
                                        <th>Nomor Ujian</th>
                                        <th>Jenis Kelamin</th>
                                        <th>Tempat/Tanggal Lahir</th>
                                        <th>Orang Tua/Wali</th>
                                        <th>Stauts</th>
                                        <th>Keterangan</th>
                                        <th>Alamat</th>
                                        <th>Email</th>
                                        <th>No. HP</th>
                                        <th>Nomor Surat</th>
                                        <th>Tanggal Surat</th>
                                        <th>Kepala Sekolah</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $nomor = 0; ?>
                                    <?php $__currentLoopData = $Siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $nomor++; ?>
                                        <tr>
                                            <td><?= $nomor ?></td>
                                            <td>
                                                <a href="<?php echo e(url('siswa/kirimemail/' . $item->nisn)); ?>"
                                                    class="btn btn-info btn-sm m-1" data-bs-toggle="tooltip" data-bs-placement="top"
                                                    title="kirim pesan email"><i class="fas fa-envelope"></i></a>
                                                <a href="<?php echo e(url('siswa/hapus/' . $item->nisn)); ?>"
                                                    class="btn btn-danger btn-sm m-1" data-bs-toggle="tooltip" data-bs-placement="top"
                                                    title="hapus data siswa/i kelulusan"
                                                    data-confirm-delete="true"><i class="fas fa-trash"></i></a>
                                                <button class="btn btn-primary btn-sm m-1" data-bs-toggle="modal"
                                                    data-bs-target="#editData<?php echo e($item->nisn); ?>"
                                                    title="tambah data siswa"><i class="fas fa-pencil"></i></button>
                                                
                                                <div class="modal fade" id="editData<?php echo e($item->nisn); ?>" tabindex="-1"
                                                    role="dialog" aria-hidden="true" data-bs-keyboard="false"
                                                    data-bs-backdrop="static">
                                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                                        <div class="modal-content">
                                                            <form method="POST"
                                                                action="<?php echo e(url('siswa/update/' . $item->nisn)); ?>"
                                                                enctype="multipart/form-data">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">EDIT DATA SISWA</h5>
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal" aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body m-3">
                                                                    <div class="row">
                                                                        <div class="col-12 col-lg-12">
                                                                            <div class="mb-3">
                                                                                <label>Priode Kelulusan</label>
                                                                                <select class="form-control select2"
                                                                                    name="periode_lulus"
                                                                                    data-bs-toggle="select2" required>
                                                                                    <?php $__currentLoopData = $GetPeriode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <?php if($row->id_periode == $item->id_periode): ?>
                                                                                            <option
                                                                                                value="<?= $row->id_periode ?>"
                                                                                                selected>
                                                                                                <?= $row->judul_periode ?>
                                                                                            </option>
                                                                                        <?php else: ?>
                                                                                            <option
                                                                                                value="<?= $row->id_periode ?>"
                                                                                                >
                                                                                                <?= $row->judul_periode ?>
                                                                                            </option>
                                                                                        <?php endif; ?>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-12 col-lg-6">
                                                                            <div class="mb-3">
                                                                                <label>Nomor Surat</label>
                                                                                <input type="text" name="nomor_surat" class="form-control"
                                                                                    placeholder="Nomor Surat" value="<?php echo e($item->nomor_surat); ?>" required>
                                                                            </div>
                                                                            <div class="mb-3">
                                                                                <label>Nama</label>
                                                                                <input type="text" name="nama_siswa"
                                                                                    value="<?php echo e($item->nama_siswa); ?>"
                                                                                    class="form-control"
                                                                                    placeholder="Nama siswa/i" required>
                                                                            </div>
                                                                            <div class="mb-3">
                                                                                <label>Tempat Lahir</label>
                                                                                <input type="text" name="tempat_lahir" class="form-control" value="<?php echo e($item->tempat_lahir); ?>"
                                                                                    placeholder="Tempat Lahir Siswa/i" required>
                                                                            </div>
                                                                            <div class="mb-3">
                                                                                <label>Tanggal Lahir</label>
                                                                                <input type="date"
                                                                                    name="tanggal_lahir_siswa"
                                                                                    value="<?= $item->tanggal_lahir_siswa ?>"
                                                                                    class="form-control" required />
                                                                            </div>
                                                                            <div class="mb-3">
                                                                                <label>Nomor Ujian</label>
                                                                                <input type="text"
                                                                                    name="nomor_ujian_siswa"
                                                                                    class="form-control"
                                                                                    value="<?php echo e($item->nomor_ujian_siswa); ?>"
                                                                                    placeholder="Nomor ujian siswa/i"
                                                                                    required>
                                                                            </div>
                                                                            <div class="mb-3">
                                                                                <label>No HP</label>
                                                                                <input type="text" name="no_hp_siswa"
                                                                                    value="<?php echo e($item->no_hp_siswa); ?>"
                                                                                    class="form-control"
                                                                                    placeholder="No HP siswa/i" required>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-12 col-lg-6">
                                                                            <div class="mb-3">
                                                                                <label>Tanggal Surat</label>
                                                                                <input type="text" name="tanggal_surat" class="form-control" value="<?php echo e($item->tanggal_surat); ?>"
                                                                                    placeholder="Pekanbaru, 21 Juli 2024" required>
                                                                            </div>
                                                                            <div class="mb-3">
                                                                                <label>NISN</label>
                                                                                <input type="text" name="nisn_siswa"
                                                                                    value="<?php echo e($item->nisn); ?>"
                                                                                    class="form-control"
                                                                                    placeholder="NISN siswa/i" required>
                                                                            </div>
                                                                            <div class="mb-3">
                                                                                <label>Jenis Kelamin</label>
                                                                                <select class="form-control mb-3"
                                                                                    name="jenis_kelmain_siswa" required>
                                                                                    <option selected>PILIH</option>
                                                                                    <?php if($item->jenis_kelamin_siswa == 'L'): ?>
                                                                                        <option value="L"selected>
                                                                                            LAKI-LAKI
                                                                                        </option>
                                                                                        <option value="P">PEREMPUAN
                                                                                        </option>
                                                                                    <?php else: ?>
                                                                                        <option value="L">LAKI-LAKI
                                                                                        </option>
                                                                                        <option value="P" selected>
                                                                                            PEREMPUAN
                                                                                        </option>
                                                                                    <?php endif; ?>
                                                                                </select>
                                                                            </div>
                                                                            <div class="mb-3">
                                                                                <label>Keterangan</label>
                                                                                <select class="form-control mb-3"
                                                                                    name="keterangan_siswa" required>
                                                                                    <option selected>PILIH</option>
                                                                                    <?php if($item->keterangan_siswa == '1'): ?>
                                                                                        <option value="1" selected>
                                                                                            LULUS
                                                                                        </option>
                                                                                        <option value="0">TIDAK LULUS
                                                                                        </option>
                                                                                    <?php else: ?>
                                                                                        <option value="1">LULUS
                                                                                        </option>
                                                                                        <option value="0" selected>
                                                                                            TIDAK
                                                                                            LULUS
                                                                                        </option>
                                                                                    <?php endif; ?>
                                                                                </select>
                                                                            </div>
                                                                            <div class="mb-3">
                                                                                <label>Email</label>
                                                                                <input type="email" name="email_siswa"
                                                                                    value="<?php echo e($item->email_siswa); ?>"
                                                                                    class="form-control"
                                                                                    placeholder="Email siswa/i" required>
                                                                            </div>
                                                                            <div class="mb-3">
                                                                                <label>Orang Tua/Wali</label>
                                                                                <input type="text" name="orang_tua" class="form-control" value="<?php echo e($item->orang_tua); ?>"
                                                                                    placeholder="Nama orang tua / wali" required>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-12 col-lg-12">
                                                                            <div class="mb-3">
                                                                                <label>Kepala Sekolah</label>
                                                                                <input type="text" name="tandat_angan_surat" class="form-control" value="<?php echo e($item->tandat_angan_surat); ?>"
                                                                                    placeholder="Nama kepala sekolah" required>
                                                                            </div>
                                                                            <label>Alamat</label>
                                                                            <textarea type="email" name="alamat_siswa" class="form-control" placeholder="Alamat siswa/i" required><?php echo e($item->alamat_siswa); ?></textarea>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-bs-dismiss="modal">Batal</button>
                                                                    <button type="submit"
                                                                        class="btn btn-primary">Simpan</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </td>
                                            
                                            <td><?= strtoupper($item->nama_siswa) ?></td>
                                            <td><?= $item->nisn ?></td>
                                            <td><?= $item->nomor_ujian_siswa ?></td>
                                            <td><?php echo e($item->jenis_kelamin_siswa == 'L' ? 'LAKI-LAKI' : 'PEREMPUAN'); ?></td>
                                            <td><?= $item->tempat_lahir.'/'.$item->tanggal_lahir_siswa ?></td>
                                            
                                            <td><?= ucwords($item->orang_tua) ?></td>
                                            <td><?php if ($item->status_siswa == '1') {
                                                echo '<span class="badge bg-success">DILIHAT</span> <br>'.date('d - F - Y  h:i:s A ', strtotime($item->updated_at));

                                            } else {
                                                echo '<span class="badge bg-danger">BELUM DILIHAT</span>';
                                            } ?></td>
                                            <td><?php echo $item->keterangan_siswa == '1' ? 'LULUS' : 'TIDAK LULUS'; ?></td>
                                            <td><?= $item->alamat_siswa ?></td>
                                            <td><?= $item->email_siswa ?></td>
                                            <td><?= $item->no_hp_siswa ?></td>
                                            <td><?= $item->nomor_surat ?></td>
                                            <td><?= $item->tanggal_surat ?></td>
                                            <td><?= $item->tandat_angan_surat ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="modal fade" id="centeredModalPrimary" tabindex="-1" role="dialog"
                            aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <form method="POST" action="<?php echo e(url('siswa/upload')); ?>"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-header">
                                            <h5 class="modal-title">IMPORT DATA SISWA</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body m-3">
                                            <div class="row">
                                                <div class="col-12 col-lg-12">
                                                    <input type="text" name="id_periode"
                                                        value="<?php echo e($Periode->id_periode); ?>" hidden>
                                                    <div class="mb-3">
                                                        <label class="form-label w-100">File input</label>
                                                        <input type="file" name="file_siswa" required>
                                                        <small class="form-text d-block text-muted">format file excel <a
                                                                href="">klik disini</a></small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Batal</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sik_web\resources\views/Admin/siswa/data_detail.blade.php ENDPATH**/ ?>