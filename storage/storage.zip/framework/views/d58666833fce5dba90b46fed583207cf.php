
<?php $__env->startSection('content'); ?>
    <div class="container" style="height: 100%; display: flex; justify-content: center; align-items: center;">
        <table>
            <tr>
                <td style="padding: 10px;">
                    </br>
                    <div class="container" style="height: 100%; display: flex; justify-content: center; align-items: center;">
                        <div style="top: 50%; ">
                            <div class="well" style="margin-top: 0px;">
                                <p align='center'><img src='<?php echo e(asset('storage/' . $Sistem->logo_sistem)); ?>' height='85' />
                                </p>
                                <h4 align='center' style='margin: 15px 0 -10px 0;'><b>SISTEM INFORMASI</br>STATUS KELULUSAN
                                        SISWA<br><?php echo e($Sistem->nama_sekolah); ?></b></h4>
                                <hr>
                                <div align='center' class='alert alert-dismissable alert-danger'>
                                    <h4><b>DETAIL STATUS KELULUSAN</b></h4>
                                </div>
                                <table min-width='100' class='table table-striped table-bordered'>";
                                    <tr class='success'>
                                        <td colspan='4' align='center'>
                                            <font color='#000000' size='4' style='font-weight: bold;';><b>IDENTITAS
                                                    PESERTA DIDIK</b>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Nama Lengkap</td>
                                        <td colspan='3'>
                                            <font style='text-transform: capitalize;'><strong>:
                                                    <?php echo e($Siswa->nama_siswa); ?></strong></font>
                                        </td>
                                    </tr>

                                    <tr class='secondary'>
                                        <td width='250'>NISN </td>
                                        <td width='480'><strong>: <?php echo e($Siswa->nisn); ?> </strong></td>
                                    </tr>

                                    <tr class='secondary'>
                                        <td width='250'>Nomor Ujian </td>
                                        <td width='480'><strong>: <?php echo e($Siswa->nomor_ujian_siswa); ?> </strong></td>
                                    </tr>

                                    <tr class='secondary'>
                                        <td>Tempat/ Tgl. Lahir</td>
                                        <td colspan='3'>
                                            <font style='text-transform: uppercase;'><strong>:
                                                    <?php echo e($Siswa->tempat_lahir . ' / ' . date('d - m - Y', strtotime($Siswa->tanggal_lahir_siswa))); ?></strong>
                                            </font>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>Jenis Kelamin</td>
                                        <td colspan='3'>
                                            <font style='text-transform: capitalize;'><strong>:
                                                    <?php echo e($Siswa->jenis_kelamin_siswa == 'L' ? 'LAKI - LAKI' : 'PEREMPUAN'); ?></strong>
                                            </font>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>Alamat</td>
                                        <td colspan='3'><strong>: <?php echo e($Siswa->alamat_siswa); ?></strong></td>
                                    </tr>

                                    <tr class='success'>
                                        <td colspan='4' align='center'>
                                            <font color='#000000' size='4' style='font-weight: bold;';>STATUS
                                                KELULUSAN DINYATAKAN
                                        </td>
                                    </tr>

                                    <tr class='warning'>
                                        <td colspan='4' align='center'>
                                            <font color='#0066FF' size='6' style='text-transform: uppercase;'>
                                                <b><?php echo e($Siswa->keterangan_siswa == '1' ? 'LULUS' : 'TIDAK LULUS'); ?></b>
                                        </td>
                                    </tr>
                                    <tr class='success'>
                                        <td colspan='4' align='center'><b>Apapun hasil yang didapat, semoga ini adalah
                                                yang terbaik, tetap
                                                semangat dan optimis.</b></td>
                                    </tr>

                                    <tr class='secondary'>
                                        <td colspan='4'></td>
                                    </tr>
                                    <tr class='danger'>
                                        <td colspan='4' align='center'>
                                            <b>Catatan:</b> Jika ada perbedaan data pengumuman online dan manual,</br>maka
                                            yang menjadi acuan
                                            adalah dokumen asli Kelulusan yang telah disahkan, <i></br>ditandatangani oleh Kepala Sekolah dan diberi cap basah sekolah</i>.
                                        </td>
                                    </tr>
                                </table>
                                <div class='form-group' style='margin-bottom: 10px;'>
                                    <p align='center'>
                                        <a href='<?php echo e(url('logout')); ?>' class='btn btn-success'>
                                            BACK
                                        </a>
                                        <a href='<?php echo e(url('cetak_pdf/' . $Periode->id_periode . '/' . $Siswa->nisn . '/' . $Siswa->nomor_ujian_siswa)); ?>'
                                            class='btn btn-danger'>
                                            PRINT
                                        </a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Online.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sik_web\resources\views/Online/detail_data.blade.php ENDPATH**/ ?>