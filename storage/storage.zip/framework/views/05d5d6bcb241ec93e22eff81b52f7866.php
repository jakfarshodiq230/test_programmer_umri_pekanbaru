<!DOCTYPE html
    PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title><?php echo e($Sistem->nama_sistem); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>" media="screen">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" media="screen">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootswatch.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/jasny-bootstrap.min.css')); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/logo.png')); ?>">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
    <script type="text/javascript" async="" src="<?php echo e(asset('assets/js/ga.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery-1.10.2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootswatch.js')); ?>"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
    </style>
</head>

<body style="background: url('<?php echo e(asset('assets/images/bg.png')); ?>) repeat;">
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <a href="<?php echo e(url('/')); ?>" class="navbar-brand"><b><?php echo e($Sistem->nama_sistem); ?></b> </a>;
                <button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-main">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="navbar-collapse collapse" id="navbar-main">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="<?php echo e(url('kontak')); ?>"><b>CONTAK</b></a></li>
                </ul>
            </div>
        </div>
    </div>

    
    <?php echo $__env->yieldContent('content'); ?>
    

    <div class="navbar navbar-inverse navbar-fixed-bottom">
        <h5 align="center" style="color:#ffff;"><?php echo e($Sistem->nama_sekolah); ?></br><?php echo e($Sistem->nama_sistem); ?> &copy
            <?= date('Y', strtotime($Sistem->tanggal_sistem)) ?></h5>
    </div>
    <?php
    if ($Periode == true) {
        $tanggal = date('Y-m-d h:i:s ', strtotime($Periode->tanggal_jam_periode));
    }
    ?>
    <script src="<?php echo e(asset('assets/js/jquery.countdown.min.js')); ?>"></script>
    <?php if($Periode == true): ?>
        <script>
            var skrg = Date.now();

            $('#clock').countdown("<?= $tanggal ?>", {
                    elapse: true
                })
                .on('update.countdown', function(event) {
                    var $this = $(this);
                    if (event.elapsed) {
                        $("#xpengumuman").show();
                        $("#clock").hide();
                    } else {
                        $this.html(event.strftime(
                            '<strong>WAKTU PENGUMUMAN KELULUSAN </br>%D HARI %H JAM %M MENIT %S DETIK</strong>'));
                        $("#xpengumuman").hide();
                    }
                });
        </script>
    <?php endif; ?>

</body>

</html>
<?php /**PATH C:\laragon\www\sik_web\resources\views/Online/layout.blade.php ENDPATH**/ ?>