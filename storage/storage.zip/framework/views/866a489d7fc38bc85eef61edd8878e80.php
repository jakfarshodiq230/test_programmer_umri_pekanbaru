
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid">

            <div class="header">
                <h1 class="header-title">
                    Selamat Datang, <?php echo e(Auth::user()->nama_user); ?> !
                </h1>
            </div>

            <div class="row">
                <div class="col-xl-6 col-xxl-7">
                    <div class="card flex-fill w-100">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Kelulusan</h5>
                        </div>
                        <div class="card-body py-3">
                            <div class="chart chart-sm">
                                <canvas id="chartjs-dashboard-line"></canvas>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-6 col-xxl-5 d-flex">
                    <div class="w-100">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col mt-0">
                                                <h5 class="card-title">LULUS</h5>
                                            </div>

                                            <div class="col-auto">
                                                <div class="avatar">
                                                    <div class="avatar-title rounded-circle bg-success-dark">
                                                        <i class="align-middle" data-feather="user-check"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <h1 class="display-5 mt-1 mb-3"><?php echo e($siswaLulus); ?></h1>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col mt-0">
                                                <h5 class="card-title">PRIODE</h5>
                                            </div>

                                            <div class="col-auto">
                                                <div class="avatar">
                                                    <div class="avatar-title rounded-circle bg-primary-dark">
                                                        <i class="align-middle" data-feather="settings"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <h1 class="display-5 mt-1 mb-3"><?php echo e($periode); ?></h1>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col mt-0">
                                                <h5 class="card-title">TIDAK LULUS</h5>
                                            </div>

                                            <div class="col-auto">
                                                <div class="avatar">
                                                    <div class="avatar-title rounded-circle bg-danger-dark">
                                                        <i class="align-middle" data-feather="user-x"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <h1 class="display-5 mt-1 mb-3"><?php echo e($siswaTidakLulus); ?></h1>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col mt-0">
                                                <h5 class="card-title">PENGGUNA</h5>
                                            </div>

                                            <div class="col-auto">
                                                <div class="avatar">
                                                    <div class="avatar-title rounded-circle bg-primary-dark">
                                                        <i class="align-middle" data-feather="users"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <h1 class="display-5 mt-1 mb-3"><?php echo e($pengguna); ?></h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12 col-md-6 col-xxl-3 d-flex order-1 order-xxl-1">
                    <div class="card flex-fill">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Calendar</h5>
                        </div>
                        <div class="card-body d-flex">
                            <div class="align-self-center w-100">
                                <div class="chart">
                                    <div id="datetimepicker-dashboard"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-xxl-3 d-flex order-2 order-xxl-3">
                    <div class="card flex-fill w-100">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Browser Usage</h5>
                        </div>
                        <div class="card-body d-flex">
                            <div class="align-self-center w-100">
                                <div class="py-3">
                                    <div class="chart chart-xs">
                                        <canvas id="chartjs-doughnut"></canvas>
                                    </div>
                                </div>

                                <table class="table mb-0">
                                    <tbody>
                                        <?php $kode = 0; ?>
                                        <?php $__currentLoopData = $DataGrafikAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $browser_short => $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            $warna = '';
                                            $kode = $kode + 1;
                                            if ($kode == 1) {
                                                $warna = 'text-primary';
                                            } elseif ($kode == 2) {
                                                $warna = 'text-success';
                                            } elseif ($kode == 3) {
                                                $warna = 'text-warning';
                                            } else {
                                                $warna = 'style="background: #E8EAED;"';
                                            }
                                            
                                            ?>
                                            <tr>
                                                <td><i class="fas fa-circle <?php if ($kode <= 3) {
                                                    echo $warna;
                                                } ?> fa-fw"
                                                        <?php if ($kode > 3) {
                                                            echo $warna;
                                                        } ?>></i><?php echo e($browser_short); ?></td>
                                                <td class="text-end"><?php echo e($total); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    var labelTahun = '<?= $labelTahun ?>';
    var dataLulus = '<?= $dataLulus ?>';
    var dataTidakLulus = '<?= $dataTidakLulus ?>';

    document.addEventListener("DOMContentLoaded", function() {
        new Chart(document.getElementById("chartjs-dashboard-line"), {
            type: 'line',
            data: {
                labels: [
                    <?php
                    $labelTahunArray = explode('","', $labelTahun);
                    foreach ($labelTahunArray as $label) {
                        echo "'" . $label . "', ";
                    }
    
    ?>
                ],
                datasets: [{
                        label: "Lulus",
                        fill: true,
                        backgroundColor: window.theme.primary,
                        borderColor: window.theme.primary,
                        borderWidth: 2,
                        data: [
                            <?php
                            $dataLulusArray = explode(' ', $dataLulus);
                            foreach ($dataLulusArray as $data) {
                                echo $data . ', ';
                            }
    
    ?>
                        ]
                    },
                    {
                        label: "Tidak Lulus",
                        fill: true,
                        backgroundColor: "rgba(0, 0, 0, 0.05)",
                        borderColor: "rgba(0, 0, 0, 0.05)",
                        borderWidth: 2,
                        data: [
                            <?php
                            $dataTidakLulusArray = explode(' ', $dataTidakLulus);
                            foreach ($dataTidakLulusArray as $data) {
                                echo $data . ', ';
                            }
    
    ?>
                        ]
                    }
                ]
            },
            options: {
                maintainAspectRatio: false,
                legend: {
                    display: false
                },
                tooltips: {
                    intersect: false
                },
                hover: {
                    intersect: true
                },
                plugins: {
                    filler: {
                        propagate: false
                    }
                },
                elements: {
                    point: {
                        radius: 0
                    }
                },
                scales: {
                    xAxes: [{
                        reverse: true,
                        gridLines: {
                            color: "rgba(0,0,0,0.0)"
                        }
                    }],
                    yAxes: [{
                        ticks: {
                            stepSize: 5
                        },
                        display: true,
                        gridLines: {
                            color: "rgba(0,0,0,0)",
                            fontColor: "#fff"
                        }
                    }]
                }
            }
        });
    });
    
</script>
<script>
    var dataBrowser = '<?= $dataBrowser ?>';
    var dataArray = dataBrowser.split(' ');
    document.addEventListener("DOMContentLoaded", function() {
        // Pie chart
        new Chart(document.getElementById("chartjs-doughnut"), {
            type: "doughnut",
            data: {
                labels: [
                    <?php
                    $labelBrowserArray = explode(' ', $labelBrowser);
                    foreach ($labelBrowserArray as $label) {
                        echo "'" . $label . "', ";
                    }
                    ?>
                ],

                datasets: [{
                    data: [
                        <?php
                        $dataArray = explode(' ', $dataBrowser);
                        foreach ($dataArray as $data) {
                            echo $data . ', ';
                        }
                        ?>
                    ],
                    backgroundColor: [
                        window.theme.primary,
                        window.theme.success,
                        window.theme.warning,
                        "#E8EAED"
                    ],
                    borderColor: "transparent"
                }]
            },
            options: {
                maintainAspectRatio: false,
                cutoutPercentage: 65,
                legend: {
                    display: false
                }
            }
        });
    });
</script>
<script>
    $(function() {
        $('#datetimepicker-dashboard').datetimepicker({
            inline: true,
            sideBySide: false,
            format: 'L'
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sik_web\resources\views/Admin/home/home.blade.php ENDPATH**/ ?>