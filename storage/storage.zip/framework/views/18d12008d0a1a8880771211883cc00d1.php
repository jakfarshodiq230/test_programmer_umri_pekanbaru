
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid">

            <div class="header">
                <h1 class="header-title">
                    Data Pengguna
                </h1>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-actions float-end">
                                <div>
                                    <button class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#centeredModalPrimary" title="tambah data siswa"><i
                                            class="fas fa-add"></i></button>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table id="datatables-buttons" class="table table-striped" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Nama</th>
                                        <th>Email</th>
                                        <th>No. HP</th>
                                        <th>Email</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $nomor = 0; ?>
                                    <?php $__currentLoopData = $Pengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $nomor++; ?>
                                        <tr>
                                            <td><?= $nomor ?></td>
                                            <td><?= strtoupper($item->nama_user) ?></td>
                                            <td><?= $item->email ?></td>
                                            <td><?= $item->no_hp_user ?></td>
                                            <td><?= strtoupper($item->level_user) ?></td>
                                            <td><?php echo e($item->status_user == '1' ? 'AKTIF' : 'TIDAK AKTIF'); ?></td>
                                            <td>
                                                <a href="<?php echo e(url('pengguna/hapus/' . $item->id)); ?>"
                                                    class="btn btn-danger m-1" data-bs-toggle="tooltip" data-bs-placement="top"
                                                    title="hapus data siswa/i perpriode kelulusan"
                                                    data-confirm-delete="true"><i class="fas fa-trash"></i></a>

                                                <?php if($item->status_user == 1): ?>
                                                    <a href="<?php echo e(url('pengguna/status/'.$item->id.'/0')); ?>"
                                                        class="btn btn-info m-1" title="Update status tidak aktif" data-bs-toggle="tooltip" data-bs-placement="top"
                                                        ><i class="fas fa-user-lock"></i></a>
                                                <?php else: ?>
                                                    <a href="<?php echo e(url('pengguna/status/'.$item->id.'/1')); ?>"
                                                        class="btn btn-success" title="Update status aktif" data-bs-toggle="tooltip" data-bs-placement="top"
                                                        ><i class="fas fa-user-check"></i></a>
                                                <?php endif; ?>

                                                <button class="btn btn-warning m-1" data-bs-toggle="modal"
                                                    data-bs-target="#editUser<?= $item->id ?>"
                                                    title="edit data pengguna"><i class="fas fa-pencil"></i></button>

                                                <button class="btn btn-primary m-1" data-bs-toggle="modal"
                                                    data-bs-target="#editPass<?= $item->id ?>"
                                                    title="Update Password"><i class="fas fa-key"></i></button>

                                                
                                                <div class="modal fade" id="editUser<?= $item->id ?>" tabindex="-1"
                                                    role="dialog" aria-hidden="true" data-bs-keyboard="false"
                                                    data-bs-backdrop="static">
                                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                                        <div class="modal-content">
                                                            <form method="POST"
                                                                action="<?php echo e(url('pengguna/rubah/' . $item->id)); ?>"
                                                                enctype="multipart/form-data">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">EDIT PENGGUNA</h5>
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal" aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body m-3">
                                                                    <div class="row">
                                                                        <div class="col-12 col-lg-12">
                                                                            <div class="mb-3">
                                                                                <label>Nama</label>
                                                                                <input type="text" name="nama_user"
                                                                                    class="form-control"
                                                                                    value="<?php echo e($item->nama_user); ?>"
                                                                                    placeholder="nama pengguna" required>
                                                                            </div>
                                                                            <div class="mb-3">
                                                                                <label>Email</label>
                                                                                <input type="email" name="email_user"
                                                                                    value="<?php echo e($item->email); ?>"
                                                                                    class="form-control" placeholder="email"
                                                                                    required>
                                                                            </div>
                                                                            <div class="mb-3">
                                                                                <label>No. HP</label>
                                                                                <input type="text" name="no_hp_user"
                                                                                    class="form-control"
                                                                                    value="<?php echo e($item->no_hp_user); ?>"
                                                                                    placeholder="No. HP" required>
                                                                            </div>
                                                                            
                                                                            <div class="mb-3">
                                                                                <label>Level</label>
                                                                                <select class="form-control select2"
                                                                                    name="level_user"
                                                                                    data-bs-toggle="select2" required>
                                                                                    <option>PILIH</option>
                                                                                    <?php if($item->level_user == 'admin'): ?>
                                                                                        <option value="admin" selected>
                                                                                            Admin
                                                                                        </option>
                                                                                        <option value="superadmin">
                                                                                            Superadmin
                                                                                        </option>
                                                                                    <?php else: ?>
                                                                                        <option value="admin">Admin
                                                                                        </option>
                                                                                        <option value="superadmin" selected>
                                                                                            Superadmin
                                                                                        </option>
                                                                                    <?php endif; ?>

                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-bs-dismiss="modal">Batal</button>
                                                                    <button type="submit"
                                                                        class="btn btn-primary">Simpan</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                

                                                
                                                <div class="modal fade" id="editPass<?= $item->id ?>" tabindex="-1"
                                                    role="dialog" aria-hidden="true" data-bs-keyboard="false"
                                                    data-bs-backdrop="static">
                                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                                        <div class="modal-content">
                                                            <form method="POST"
                                                                action="<?php echo e(url('pengguna/rubahPass/' . $item->id)); ?>"
                                                                enctype="multipart/form-data">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">EDIT PASWORD</h5>
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"
                                                                        aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body m-3">
                                                                    <div class="row">
                                                                        <div class="col-12 col-lg-12">
                                                                            <div class="mb-3">
                                                                                <label>New Password</label>
                                                                                <input type="password" name="password"
                                                                                    class="form-control"
                                                                                    placeholder="password baru" required>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-bs-dismiss="modal">Batal</button>
                                                                    <button type="submit"
                                                                        class="btn btn-primary">Simpan</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>

                        </div>

                        
                        <div class="modal fade" id="centeredModalPrimary" tabindex="-1" role="dialog"
                            aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <form method="POST" action="<?php echo e(url('pengguna/simpan')); ?>"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-header">
                                            <h5 class="modal-title">TAMBAH PENGGUNA</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body m-3">
                                            <div class="row">
                                                <div class="col-12 col-lg-12">
                                                    <div class="mb-3">
                                                        <label>Nama</label>
                                                        <input type="text" name="nama_user" class="form-control"
                                                            placeholder="nama pengguna" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label>Email</label>
                                                        <input type="email" name="email_user" class="form-control"
                                                            placeholder="email" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label>Password</label>
                                                        <input type="password" name="password_user" class="form-control"
                                                            placeholder="password" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label>No. HP</label>
                                                        <input type="text" name="no_hp_user" class="form-control"
                                                            placeholder="No. HP" required>
                                                    </div>
                                                    
                                                    <div class="mb-3">
                                                        <label>Level</label>
                                                        <select class="form-control select2" name="level_user"
                                                            data-bs-toggle="select2" required>
                                                            <option selected>PILIH</option>
                                                            <option value="admin">Admin</option>
                                                            <option value="superadmin">Superadmin</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Batal</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sik_web\resources\views/Admin/pengguna/data_pengguna.blade.php ENDPATH**/ ?>