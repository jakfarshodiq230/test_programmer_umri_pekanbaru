
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid">

            <div class="header">
                <h1 class="header-title">
                    Seting Sistem
                </h1>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <form method="POST" action="<?php echo e(url('sistem/rubahSistem/' . $Sistem->id_sistem)); ?>"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="card-header">
                                <h5 class="card-title mb-0">Info Sistem </h5>
                            </div>
                            <div class="card-body">

                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="mb-3">
                                            <label for="inputUsername">Nama Sekolah</label>
                                            <input type="text" class="form-control" id="nama_sekolah" name="nama_sekolah"
                                                value="<?php echo e($Sistem->nama_sekolah); ?>" placeholder="nama sekolah">
                                        </div>
                                        <div class="mb-3">
                                            <label for="inputUsername">Nama Sistem</label>
                                            <input type="text" class="form-control" id="nama_sistem" name="nama_sistem"
                                                value="<?php echo e($Sistem->nama_sistem); ?>" placeholder="nama sistem">
                                        </div>
                                        <div class="mb-3">
                                            <label for="inputUsername">Tanggal Sistem</label>
                                            <input type="date" name="tanggal_sistem" id="tanggal_sistem"
                                                value="<?php echo e($Sistem->tanggal_sistem); ?>" class="form-control" required />
                                        </div>
                                        <div class="mb-3">
                                            <label for="inputUsername">Nomor HP</label>
                                            <input type="text" name="no_hp_sistem" id="no_hp_sistem"
                                                value="<?php echo e($Sistem->no_hp_sistem); ?>" class="form-control" required />
                                        </div>
                                        <div class="mb-3">
                                            <label for="inputUsername">Email</label>
                                            <input type="email" name="email_sistem" id="email_sistem"
                                                value="<?php echo e($Sistem->email_sistem); ?>" class="form-control" required />
                                        </div>
                                        <div class="mb-3">
                                            <label for="inputUsername">Alamat</label>
                                            <textarea name="alamat_sistem" id="alamat_sistem" class="form-control" required ><?php echo e($Sistem->alamat_sistem); ?></textarea>
                                        </div>
                                        <?php if($errors->any()): ?>
                                            <div class="alert alert-danger alert-outline-coloured alert-dismissible p-2"
                                                role="alert">
                                                <div class="alert-icon">
                                                    <i class="far fa-fw fa-bell"></i>
                                                </div>
                                                <div class="alert-message">
                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li class="text-danger"><?php echo e($error); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                <button type="button" class="btn-close " data-bs-dismiss="alert"
                                                    aria-label="Close"></button>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="text-center">
                                            <div class="mt-2">
                                                <span>Logo Sekarang</span>
                                            </div>
                                            <?php if($Sistem->logo_sistem == null): ?>
                                                <img alt="Chris Wood"
                                                    src="<?php echo e(asset('assets/admin/img/avatars/avatar.jpg')); ?>"
                                                    class="rounded-circle img-responsive mt-2" width="128"
                                                    height="128" />
                                            <?php else: ?>
                                                <img alt="Chris Wood" src="<?php echo e(asset('storage/' . $Sistem->logo_sistem)); ?>"
                                                    class="rounded-circle img-responsive mt-2" width="128"
                                                    height="128" />
                                            <?php endif; ?>

                                            <div class="mt-2">
                                                <span class="btn btn-primary"><input type="file" name="file_logo"
                                                        id="file_logo"></span>
                                            </div>
                                            <small>For best results, use an image at least 128px by 128px in .jpg
                                                format</small>
                                        </div>
                                    </div>
                                </div>

                                <button type="button" onclick="toggleInputs()" class="btn btn-warning">Edit Data</button>
                                <button type="submit" id="submitBtn" class="btn btn-primary">Update</button>

                                <script>
                                    document.getElementById("submitBtn").disabled = true;
                                    var inputs = ['nama_sekolah','nama_sistem', 'tanggal_sistem', 'file_logo'];
                                    inputs.forEach(function(id) {
                                        var inputField = document.getElementById(id);
                                        inputField.readOnly = !inputField.readOnly;
                                    });

                                    function toggleInputs() {
                                        document.getElementById("submitBtn").disabled = false;
                                        var inputs = ['nama_sekolah','nama_sistem', 'tanggal_sistem', 'file_logo'];
                                        inputs.forEach(function(id) {
                                            var inputField = document.getElementById(id);
                                            inputField.readOnly = !inputField.readOnly;
                                        });
                                    }
                                </script>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sik_web\resources\views/Admin/sistem/data_sistem.blade.php ENDPATH**/ ?>