
<?php $__env->startSection('content'); ?>
    <div class="container" style="height: 100%; display: flex; justify-content: center; align-items: center;">
        <table>
            <tr>
                <td style="padding: 10px;">
                    </br>
                    <div class="container" style="height: 100%; display: flex; justify-content: center; align-items: center;">
                        <div style="top: 50%; transform:translate(0, -50%); position: absolute;">
                            <div class="well">
                                <p align="center"><img src="<?php echo e(asset('storage/' . $Sistem->logo_sistem)); ?>" height="85" />
                                </p>
                                <h4 align="center" style="margin: 15px 0 -10px 0;"><b>SISTEM INFORMASI</br>STATUS
                                        KELULUSAN SISWA<br><?php echo e($Sistem->nama_sekolah); ?></b></h4>
                                <hr>
                                <!-- countdown -->
                                <h4 align=" center">
                                    <div id="clock" class="alert alert-dismissable alert-success" style="padding:10px">
                                    </div>
                                </h4>
                                <div id="xpengumuman">
                                    <div class="alert alert-dismissable alert-success" style="text-align: center">
                                        <h4 align=" center">
                                            <b><?php echo e(strtoupper($Periode->judul_periode)); ?></br> <?php echo e($Periode->tahun_periode); ?> DIBUKA
                                            </b>
                                        </h4>
                                    </div>
                                    <hr>
                                    <form class="form-horizontal" form name="formcarino" method="POST" action="<?php echo e(url('detail_data/'.$Periode->id_periode)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <fieldset id="xpengumuman">
                                            <div class="form-group">
                                                <input type="text" class="form-control" style="margin-bottom: 5px;"
                                                    name="nisn" onkeypress="return hanyaAngka(event)"
                                                    placeholder="NOMOR NISN" size="auto" required
                                                    oninvalid="this.setCustomValidity('Nomor nisn tidak boleh kosong')"
                                                    oninput="setCustomValidity('')">
                                                <input type="text" class="form-control" name="nomor_ujian"
                                                    onkeypress="return hanyaAngka(event)"
                                                    placeholder="NOMOR UJIAN" size="auto" required
                                                    oninvalid="this.setCustomValidity('Nomor ujian tidak boleh kosong')"
                                                    oninput="setCustomValidity('')">
                                            </div>
                                            <div class="form-group" style="margin-bottom: -10px;">
                                                <p align="center"><button type="SUBMIT" name="SUBMIT" id="SUBMIT"
                                                        value="PERIKSA DATA" class="btn btn-danger">PERIKSA DATA</button></p>
                                            </div>
                                        </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Online.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sik_web\resources\views/Online/cari_data.blade.php ENDPATH**/ ?>