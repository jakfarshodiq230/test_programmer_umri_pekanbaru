
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid">

            <div class="header">
                <h1 class="header-title">
                    Data Pengunjung Sistem
                </h1>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-actions float-end">
                                <div>
                                    <a href="<?php echo e(url('pengunjung/hapus')); ?>"
                                    class="btn btn-primary m-1" data-bs-toggle="tooltip" data-bs-placement="top"
                                    title="Menghapus seluruh data pengunjung"
                                    data-confirm-delete="true"><i class="fas fa-trash" style="color: white;"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="card-body mt-4">
                            <table id="datatables-buttons" class="table table-striped" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>IP Address</th>
                                        <th>Browser</th>
                                        <th>Platform</th>
                                        <th>Device</th>
                                        <th>Negara</th>
                                        <th>Waktu</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $nomor = 0; ?>
                                    <?php $__currentLoopData = $Pengunjung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $nomor++; ?>
                                        <tr>
                                            <td><?= $nomor ?></td>
                                            <td><?= $item->ip_address ?></td>
                                            <td><?= $item->browser ?></td>
                                            <td><?= $item->platform ?></td>
                                            <td><?= $item->device ?></td>
                                            <td><?php echo'<span class="badge bg-success">'.$item->negara.'</span>'; ?></td>
                                            <td><?= date('d - F - Y  h:i:s A ', strtotime($item->created_at)) ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sik_web\resources\views/Admin/home/pengunjung.blade.php ENDPATH**/ ?>